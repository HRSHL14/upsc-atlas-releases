/* Knowledge Atlas offline cache. Bump CACHE_VERSION when deploying incompatible assets. */
const CACHE_VERSION = 'v24';
const STATIC_CACHE = `atlas-static-${CACHE_VERSION}`;
const DATA_CACHE = `atlas-data-${CACHE_VERSION}`;
const TILE_CACHE = `atlas-tiles-${CACHE_VERSION}`;
const APP_SHELL = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  '/favicon-32x32.png',
  '/favicon-16x16.png',
  '/favicon.svg',
  '/apple-touch-icon.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-maskable-192.png',
  '/icons/icon-maskable-512.png',
  '/config/layers.json'
];
const MAX_DATA_ENTRIES = 80;
const MAX_DATA_BYTES = 100 * 1024 * 1024;
const MAX_TILE_ENTRIES = 400;
const META_DB = `atlas-cache-meta-${CACHE_VERSION}`;

self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
});

function openMetaDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(META_DB, 1);
    request.onupgradeneeded = () => request.result.createObjectStore('entries', { keyPath: 'key' });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function recordCacheEntry(cacheName, request, response) {
  try {
    const db = await openMetaDb();
    const size = Number(response.headers.get('content-length')) || 0;
    const entry = { key: `${cacheName}|${request.url}`, cacheName, url: request.url, size, lastAccess: Date.now() };
    await new Promise((resolve, reject) => {
      const tx = db.transaction('entries', 'readwrite');
      tx.objectStore('entries').put(entry);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch (_) {
    // Cache metadata is optional; caching must work even if IndexedDB is unavailable.
  }
}

async function trimCache(cacheName, maxEntries, maxBytes = Infinity) {
  try {
    const db = await openMetaDb();
    const entries = await new Promise((resolve, reject) => {
      const tx = db.transaction('entries', 'readonly');
      const request = tx.objectStore('entries').getAll();
      request.onsuccess = () => resolve(request.result.filter(entry => entry.cacheName === cacheName));
      request.onerror = () => reject(request.error);
    });
    const newestFirst = entries.sort((a, b) => b.lastAccess - a.lastAccess);
    let totalBytes = newestFirst.reduce((sum, entry) => sum + entry.size, 0);
    const cache = await caches.open(cacheName);
    const expired = newestFirst.slice(maxEntries);
    for (const entry of newestFirst.slice().reverse()) {
      if (totalBytes <= maxBytes) break;
      if (!expired.includes(entry)) expired.push(entry);
      totalBytes -= entry.size;
    }
    if (expired.length) {
      const tx = db.transaction('entries', 'readwrite');
      for (const entry of expired) {
        await cache.delete(entry.url);
        tx.objectStore('entries').delete(entry.key);
      }
      await new Promise(resolve => { tx.oncomplete = resolve; });
    }
    db.close();
  } catch (_) {}
}

async function cacheResponse(cacheName, cacheKey, response, maxEntries, maxBytes) {
  if (!response || (!response.ok && response.type !== 'opaque')) return;
  try {
    const cache = await caches.open(cacheName);
    await cache.put(cacheKey, response.clone());
    await recordCacheEntry(cacheName, cacheKey, response);
    await trimCache(cacheName, maxEntries, maxBytes);
  } catch (_) {
    // Quota limits or private browsing must not break the live request.
  }
}

function dataCacheKey(request) {
  const url = new URL(request.url);
  url.search = ''; // Cache-busting query strings should not duplicate a GeoJSON download.
  return new Request(url.toString(), { method: 'GET' });
}

async function staleWhileRevalidate(request, cacheName, cacheKey, maxEntries, maxBytes) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(cacheKey);
  const refresh = fetch(request)
    .then(async response => {
      await cacheResponse(cacheName, cacheKey, response, maxEntries, maxBytes);
      return response;
    })
    .catch(() => null);

  if (cached) {
    recordCacheEntry(cacheName, cacheKey, cached);
    return { response: cached, refresh };
  }
  return { response: await refresh, refresh: Promise.resolve() };
}

self.addEventListener('install', event => {
  event.waitUntil(caches.open(STATIC_CACHE).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('atlas-') && !name.endsWith(CACHE_VERSION)).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  if (url.pathname.endsWith('version.json')) {
    event.respondWith(fetch(request));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      cacheResponse(STATIC_CACHE, new Request(new URL('/index.html', self.location.origin)), response, 30);
      return response;
    }).catch(() => caches.match('/index.html')));
    return;
  }

  if (url.origin === self.location.origin && (url.pathname.startsWith('/data/') || url.pathname.startsWith('/config/'))) {
    const cacheKey = dataCacheKey(request);
    const result = staleWhileRevalidate(request, DATA_CACHE, cacheKey, MAX_DATA_ENTRIES, MAX_DATA_BYTES);
    event.waitUntil(result.then(value => value.refresh));
    event.respondWith(result.then(value => value.response || new Response('Atlas data is unavailable offline.', { status: 503 })));
    return;
  }

  if (url.origin === self.location.origin && (url.pathname.startsWith('/assets/') || url.pathname === '/sw.js')) {
    const result = staleWhileRevalidate(request, STATIC_CACHE, request, 30);
    event.waitUntil(result.then(value => value.refresh));
    event.respondWith(result.then(value => value.response || fetch(request)));
    return;
  }

  if (url.hostname.endsWith('basemaps.cartocdn.com')) {
    event.respondWith(fetch(request).then(response => {
      cacheResponse(TILE_CACHE, request, response, MAX_TILE_ENTRIES);
      return response;
    }).catch(() => caches.match(request)));
  }
});
